import { createContext } from "react";


export const productsContext = createContext();
