module.exports = {
    'fontawesome-svg-core': {
      'license': 'free'
    }
  }
  